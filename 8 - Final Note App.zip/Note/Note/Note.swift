//
//  Note.swift
//  Note
//
//  Created by Momo on 30/5/2567 BE.
//

import Foundation
import SwiftData

@Model
class Note {
    
    var title: String
    var isPinned: Bool
    var content: String
    var lastUpdated: Date
    
    init(title: String, isPinned: Bool, content: String, lastUpdated: Date) {
        self.title = title
        self.isPinned = isPinned
        self.content = content
        self.lastUpdated = lastUpdated
    }
    
}
